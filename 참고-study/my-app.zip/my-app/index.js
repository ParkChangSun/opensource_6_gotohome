var express = require('express');
var app = express();

//view는 html로 생각
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.engine('html',require('ejs').renderFile);

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended:false }));

app.use(express.static(__dirname + '/public'));

var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'aeuna',
    database: 'my_db'
});
connection.connect(function(err){
    if(err){
        console.error('error connecting: ' + err.stack);
        return;
    }
    console.log('Success DB connection');
})

var server = require('http').createServer(app);
var io = require('socket.io')(server);

// 클라이언트와 socket.io 통신
// 클라이언트와 connection에 대한 listening
// 리턴값으로 socket 객체가 넘어온다. (연결된 소켓 정보)
io.on('connection', function (socket) {
    // 소켓으로부터 login 에 대한 listening
    socket.on('login', function (data) {
      console.log('client logged-in:' + data.username);
      socket.username = data.username;
      io.emit('login', data.username);
    });
    // 소켓으로부터 chat 에 대한 listening
    socket.on('chat', function (data) {
      console.log('Message form %s: %s', socket.username, data.msg);
      var msg = {
        username: socket.username,
        msg: data.msg
      };
      io.emit('chat', msg);
    });
    // 소켓으로부터 disconnect 에 대한 listening
    socket.on('disconnect', function () {
      socket.broadcast.emit('logout', socket.username);
      console.log('user disconnected: ' + socket.username);
    });
  });

server.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});

app.get('/', function (req, res) {
    res.render('index.html',{ alert:false});
});
app.post('/',function(req,res){
    var name = req.body.name;
    var pwd = req.body.pwd;
    //console.log(name.pwd);

    //db에 쿼리 날리기
    var sql = `SELECT * FROM user_info WHERE username = ?`;
    connection.query(sql,[name],function(error,results,fields){
   // console.log(results);
        if (results.length==0){
            res.render('index.html',{ alert:true});
        }
        else {
            
            var db_pwd = results[0].password;
            if(pwd == db_pwd){
                res.render('welcome.html', {username: name});
            }
            else{
                res.render('index.html', { alert:true});
            }
        }
    });
});
app.get('/register', function (req, res) {
    res.render('register.html');
});
app.post('/register', function(req,res){
    var name = req.body.name;
    var pwd = req.body.pwd;
    var pwdconf = req.body.pwdconf; //register에 있는 값
  //DB에 쿼리를 날리기 커넥션 사용
  var sql = `INSERT INTO user_info VALUES (?,?)`;
  connection.query(sql,[name,pwd],function(error,results,fields){
      console.log(results);
  });
  res.redirect('/');
});
